function MainContent() {
    return <div className="main-content"></div>;
}

export default MainContent;
