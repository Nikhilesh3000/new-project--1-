require('dotenv').config();
const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/authRoutes');
const db = require('./config/db'); // Use this if `db.js` is in the parent folder
 

const salaryDeductionRoutes = require("./salaryDeduction") 
const app = express();

app.use(express.json());
app.use(cors());

app.use('/api', authRoutes);
app.put('/api/admin/approve-user3', (req, res) => {
  const { userId, status } = req.body;

  if (!userId || !status) {
    return res.status(400).json({ message: "Missing userId or status" });
  }

  const query = `UPDATE users3 SET  approval_status = ? WHERE id = ?`;

  db.query(query, [status, userId], (err, result) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ message: "Database error" });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ message: `User ${status} successfully` });
  });
});

// User login endpoint (with approval check)
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;

  const sql = 'SELECT * FROM users3 WHERE email = ?';
  db.query(sql, [email], (err, results) => {
    if (err || results.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = results[0];

    // Check if the user is approved
    if (user.status !== 'approved') {
      return res.status(403).json({ error: 'User is not approved' });
    }

    // You can add password checking and JWT generation here

    res.status(200).json({ message: 'Login successful' });
  });
});


// fetching data form register db
app.get("/api/users3", (req, res) => {
  // Query the 'users3' table
  db.query("SELECT * FROM users3", (err, results) => {
    if (err) {
      console.error("Error fetching users:", err);
      return res.status(500).json({ error: "Internal Server Error" });
    }

    // Send the fetched data to the frontend
    res.json(results);
  });
});



//fetching data from departments and designation

app.get("/api/departments", (req, res) => {
  db.query('SELECT * FROM departments ORDER BY departmentName', (err, departments) => {
    if (err) {
      console.error("Error fetching departments:", err)
      return res.status(500).json({ error: "Failed to fetch departments" })
    }

    // Use a counter to track when all designations are fetched
    let completed = 0
    
    // If no departments, return empty array
    if (departments.length === 0) {
      return res.json([])
    }

    // Get designations for each department
    departments.forEach((department, index) => {
      db.query(
        'SELECT * FROM designations WHERE departmentId = ? ORDER BY designationName',
        [department.id],
        (err, designations) => {
          if (err) {
            console.error("Error fetching designations:", err)
            return res.status(500).json({ error: "Failed to fetch designations" })
          }
          
          departments[index].designations = designations
          completed++
          
          // When all departments have their designations, send the response
          if (completed === departments.length) {
            res.json(departments)
          }
        }
      )
    })
  })
})



// Create a new department with designations
app.post("/api/departments", (req, res) => {
  const { departmentName, designations } = req.body

  if (!departmentName || !Array.isArray(designations)) {
    return res.status(400).json({ error: "Department name and designations array are required" })
  }

  db.getConnection((err, connection) => {
    if (err) {
      console.error("Error getting connection:", err)
      return res.status(500).json({ error: "Failed to create department" })
    }

    connection.beginTransaction((err) => {
      if (err) {
        connection.release()
        console.error("Error beginning transaction:", err)
        return res.status(500).json({ error: "Failed to create department" })
      }

      // Insert department
      connection.query(
        'INSERT INTO departments (departmentName) VALUES (?)',
        [departmentName],
        (err, result) => {
          if (err) {
            return connection.rollback(() => {
              connection.release()
              console.error("Error creating department:", err)
              res.status(500).json({ error: "Failed to create department" })
            })
          }

          const departmentId = result.insertId
          let designationsCompleted = 0
          let designationsToProcess = designations.filter(d => d.trim() !== "").length

          // If no designations, commit and return
          if (designationsToProcess === 0) {
            connection.commit((err) => {
              if (err) {
                return connection.rollback(() => {
                  connection.release()
                  console.error("Error committing transaction:", err)
                  res.status(500).json({ error: "Failed to create department" })
                })
              }

              // Get the newly created department
              connection.query(
                'SELECT * FROM departments WHERE id = ?',
                [departmentId],
                (err, newDepartment) => {
                  if (err) {
                    connection.release()
                    console.error("Error fetching new department:", err)
                    return res.status(500).json({ error: "Department created but failed to fetch details" })
                  }

                  newDepartment[0].designations = []
                  connection.release()
                  res.status(201).json(newDepartment[0])
                }
              )
            })
            return
          }



          // Insert designations
          designations.forEach(designation => {
            if (designation.trim()) {
              connection.query(
                'INSERT INTO designations (designationName, departmentId) VALUES (?, ?)',
                [designation, departmentId],
                (err) => {
                  if (err) {
                    return connection.rollback(() => {
                      connection.release()
                      console.error("Error creating designation:", err)
                      res.status(500).json({ error: "Failed to create department" })
                    })
                  }

                  designationsCompleted++
                  
                  // When all designations are inserted, commit and return
                  if (designationsCompleted === designationsToProcess) {
                    connection.commit((err) => {
                      if (err) {
                        return connection.rollback(() => {
                          connection.release()
                          console.error("Error committing transaction:", err)
                          res.status(500).json({ error: "Failed to create department" })
                        })
                      }

                      // Get the newly created department with designations
                      connection.query(
                        'SELECT * FROM departments WHERE id = ?',
                        [departmentId],
                        (err, newDepartment) => {
                          if (err) {
                            connection.release()
                            console.error("Error fetching new department:", err)
                            return res.status(500).json({ error: "Department created but failed to fetch details" })
                          }

                          connection.query(
                            'SELECT * FROM designations WHERE departmentId = ?',
                            [departmentId],
                            (err, departmentDesignations) => {
                              connection.release()
                              
                              if (err) {
                                console.error("Error fetching designations:", err)
                                return res.status(500).json({ error: "Department created but failed to fetch designations" })
                              }

                              newDepartment[0].designations = departmentDesignations
                              res.status(201).json(newDepartment[0])
                            }
                          )
                        }
                      )
                    })
                  }
                }
              )
            }
          })
        }
      )
    })
  })
})

// Update a department
app.put("/api/departments/:id", (req, res) => {
  const { id } = req.params
  const { departmentName } = req.body

  if (!departmentName) {
    return res.status(400).json({ error: "Department name is required" })
  }

  db.query(
    'UPDATE departments SET departmentName = ? WHERE id = ?',
    [departmentName, id],
    (err, result) => {
      if (err) {
        console.error("Error updating department:", err)
        return res.status(500).json({ error: "Failed to update department" })
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Department not found" })
      }

      res.json({ message: "Department updated successfully" })
    }
  )
})

// Delete a department and its designations
app.delete("/api/departments/:id", (req, res) => {
  const { id } = req.params

  db.getConnection((err, connection) => {
    if (err) {
      console.error("Error getting connection:", err)
      return res.status(500).json({ error: "Failed to delete department" })
    }

    connection.beginTransaction((err) => {
      if (err) {
        connection.release()
        console.error("Error beginning transaction:", err)
        return res.status(500).json({ error: "Failed to delete department" })
      }

      // First delete all designations for this department
      connection.query(
        'DELETE FROM designations WHERE departmentId = ?',
        [id],
        (err) => {
          if (err) {
            return connection.rollback(() => {
              connection.release()
              console.error("Error deleting designations:", err)
              res.status(500).json({ error: "Failed to delete department" })
            })
          }

          // Then delete the department
          connection.query(
            'DELETE FROM departments WHERE id = ?',
            [id],
            (err, result) => {
              if (err) {
                return connection.rollback(() => {
                  connection.release()
                  console.error("Error deleting department:", err)
                  res.status(500).json({ error: "Failed to delete department" })
                })
              }

              connection.commit((err) => {
                if (err) {
                  return connection.rollback(() => {
                    connection.release()
                    console.error("Error committing transaction:", err)
                    res.status(500).json({ error: "Failed to delete department" })
                  })
                }

                connection.release()

                if (result.affectedRows === 0) {
                  return res.status(404).json({ error: "Department not found" })
                }

                res.json({ message: "Department and its designations deleted successfully" })
              })
            }
          )
        }
      )
    })
  })
})

// Add a designation to a department
app.post("/api/departments/:departmentId/designations", (req, res) => {
  const { departmentId } = req.params
  const { designationName } = req.body

  if (!designationName) {
    return res.status(400).json({ error: "Designation name is required" })
  }

  // Check if department exists
  db.query(
    'SELECT id FROM departments WHERE id = ?',
    [departmentId],
    (err, department) => {
      if (err) {
        console.error("Error checking department:", err)
        return res.status(500).json({ error: "Failed to add designation" })
      }

      if (department.length === 0) {
        return res.status(404).json({ error: "Department not found" })
      }

      // Insert designation
      db.query(
        'INSERT INTO designations (designationName, departmentId) VALUES (?, ?)',
        [designationName, departmentId],
        (err, result) => {
          if (err) {
            console.error("Error adding designation:", err)
            return res.status(500).json({ error: "Failed to add designation" })
          }

          // Return the newly created designation
          db.query(
            'SELECT * FROM designations WHERE id = ?',
            [result.insertId],
            (err, newDesignation) => {
              if (err) {
                console.error("Error fetching new designation:", err)
                return res.status(500).json({ error: "Designation created but failed to fetch details" })
              }

              res.status(201).json(newDesignation[0])
            }
          )
        }
      )
    }
  )
})

// Update a designation
app.put("api/designations/:id", (req, res) => {
  const { id } = req.params
  const { designationName } = req.body

  if (!designationName) {
    return res.status(400).json({ error: "Designation name is required" })
  }

  db.query(
    'UPDATE designations SET designationName = ? WHERE id = ?',
    [designationName, id],
    (err, result) => {
      if (err) {
        console.error("Error updating designation:", err)
        return res.status(500).json({ error: "Failed to update designation" })
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Designation not found" })
      }

      res.json({ message: "Designation updated successfully" })
    }
  )
})

// Delete a designation
app.delete("/api/designations/:id", (req, res) => {
  const { id } = req.params

  db.query(
    'DELETE FROM designations WHERE id = ?',
    [id],
    (err, result) => {
      if (err) {
        console.error("Error deleting designation:", err)
        return res.status(500).json({ error: "Failed to delete designation" })
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Designation not found" })
      }

      res.json({ message: "Designation deleted successfully" })
    }
  )
})

// Search departments and designations
app.get("/api/search", (req, res) => {
  const { query } = req.query

  if (!query) {
    return res.status(400).json({ error: "Search query is required" })
  }

  const searchQuery = `%${query}%`

  // Search departments
  db.query(
    'SELECT * FROM departments WHERE departmentName LIKE ?',
    [searchQuery],
    (err, departments) => {
      if (err) {
        console.error("Error searching departments:", err)
        return res.status(500).json({ error: "Failed to perform search" })
      }

      // Search designations
      db.query(
        'SELECT * FROM designations WHERE designationName LIKE ?',
        [searchQuery],
        (err, designations) => {
          if (err) {
            console.error("Error searching designations:", err)
            return res.status(500).json({ error: "Failed to perform search" })
          }

          // Get unique department IDs from designations
          const departmentIds = [...new Set(designations.map(d => d.departmentId))]

          // If no matching departments or designations, return empty array
          if (departments.length === 0 && departmentIds.length === 0) {
            return res.json([])
          }

          // Get departments that have matching designations
          if (departmentIds.length > 0) {
            db.query(
              'SELECT * FROM departments WHERE id IN (?)',
              [departmentIds],
              (err, departmentsWithMatchingDesignations) => {
                if (err) {
                  console.error("Error fetching departments with matching designations:", err)
                  return res.status(500).json({ error: "Failed to perform search" })
                }

                // Combine results and remove duplicates
                const allDepartments = [...departments, ...departmentsWithMatchingDesignations]
                const uniqueDepartmentIds = [...new Set(allDepartments.map(d => d.id))]
                const uniqueDepartments = uniqueDepartmentIds.map(id => 
                  allDepartments.find(d => d.id === id)
                )

                // Get designations for each department
                let completed = 0
                
                uniqueDepartments.forEach((department, index) => {
                  db.query(
                    'SELECT * FROM designations WHERE departmentId = ?',
                    [department.id],
                    (err, deptDesignations) => {
                      if (err) {
                        console.error("Error fetching designations:", err)
                        return res.status(500).json({ error: "Failed to perform search" })
                      }
                      
                      uniqueDepartments[index].designations = deptDesignations
                      completed++
                      
                      // When all departments have their designations, send the response
                      if (completed === uniqueDepartments.length) {
                        res.json(uniqueDepartments)
                      }
                    }
                  )
                })
              }
            )
          } else {
            // No matching designations, just return departments with their designations
            let completed = 0
            
            departments.forEach((department, index) => {
              db.query(
                'SELECT * FROM designations WHERE departmentId = ?',
                [department.id],
                (err, deptDesignations) => {
                  if (err) {
                    console.error("Error fetching designations:", err)
                    return res.status(500).json({ error: "Failed to perform search" })
                  }
                  
                  departments[index].designations = deptDesignations
                  completed++
                  
                  // When all departments have their designations, send the response
                  if (completed === departments.length) {
                    res.json(departments)
                  }
                }
              )
            })
          }
        }
      )
    }
  )
})

// ✅ Fetch All Tables
app.get("/api/tables", (req, res) => {
  const query = "SHOW TABLES"
  db.query(query, (err, results) => {
    if (err) {
      console.error("❌ Tables Fetch Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json(results)
  })
})

// ✅ Income Tax Slabs
app.get("/api/income-tax-slabs", (req, res) => {
  const query = "SELECT * FROM income_tax_slabs ORDER BY from_amount"
  db.query(query, (err, results) => {
    if (err) {
      console.error("❌ Fetch Income Tax Slabs Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json(results)
  })
})

app.post("/api/income-tax-slabs", (req, res) => {
  const { from_amount, to_amount, tax_rate } = req.body
  const query = "INSERT INTO income_tax_slabs (from_amount, to_amount, tax_rate) VALUES (?, ?, ?)"
  db.query(query, [from_amount, to_amount, tax_rate], (err, result) => {
    if (err) {
      console.error("❌ Insert Income Tax Slab Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json({ id: result.insertId, from_amount, to_amount, tax_rate })
  })
})

app.put("/api/income-tax-slabs/:id", (req, res) => {
  const { id } = req.params
  const { from_amount, to_amount, tax_rate } = req.body
  const query = "UPDATE income_tax_slabs SET from_amount = ?, to_amount = ?, tax_rate = ? WHERE id = ?"
  db.query(query, [from_amount, to_amount, tax_rate, id], (err) => {
    if (err) {
      console.error("❌ Update Income Tax Slab Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json({ message: "Updated successfully" })
  })
})

app.delete("/api/income-tax-slabs/:id", (req, res) => {
  const { id } = req.params
  const query = "DELETE FROM income_tax_slabs WHERE id = ?"
  db.query(query, [id], (err) => {
    if (err) {
      console.error("❌ Delete Income Tax Slab Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json({ message: "Deleted successfully" })
  })
})

// ✅ Client Terms
app.get("/api/client-terms", (req, res) => {
  const query = "SELECT * FROM client_terms"
  db.query(query, (err, results) => {
    if (err) {
      console.error("❌ Fetch Client Terms Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json(results)
  })
})

// ✅ Expenses
app.get("/api/expenses", (req, res) => {
  const query = "SELECT * FROM expenses"
  db.query(query, (err, results) => {
    if (err) {
      console.error("❌ Fetch Expenses Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json(results)
  })
})

// ✅ Franchisee Terms
app.get("/api/franchisee-terms", (req, res) => {
  const query = "SELECT * FROM franchisee_terms"
  db.query(query, (err, results) => {
    if (err) {
      console.error("❌ Fetch Franchisee Terms Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json(results)
  })
})

// ✅ GST Rates
app.get("/api/gst-rates", (req, res) => {
  const query = "SELECT * FROM gst_rates"
  db.query(query, (err, results) => {
    if (err) {
      console.error("❌ Fetch GST Rates Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json(results)
  })
})

// ✅ Salary Data
app.get("/api/salary-data", (req, res) => {
  const query = "SELECT * FROM salary_data"
  db.query(query, (err, results) => {
    if (err) {
      console.error("❌ Fetch Salary Data Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json(results)
  })
})

// Add new salary data
app.post("/api/salary-data", (req, res) => {
  const { head_component, eligibility, limit, period, remarks } = req.body
  const query = "INSERT INTO salary_data (head_component, eligibility, limit, period, remarks) VALUES (?, ?, ?, ?, ?)"
  db.query(query, [head_component, eligibility, limit, period, remarks], (err, result) => {
    if (err) {
      console.error("❌ Insert Salary Data Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json({ id: result.insertId, head_component, eligibility, limit, period, remarks })
  })
})

// Update salary data
app.put("/api/salary-data/:id", (req, res) => {
  const { id } = req.params
  const { head_component, eligibility, limit, period, remarks } = req.body
  const query =
    "UPDATE salary_data SET head_component = ?, eligibility = ?, limit = ?, period = ?, remarks = ? WHERE id = ?"
  db.query(query, [head_component, eligibility, limit, period, remarks, id], (err) => {
    if (err) {
      console.error("❌ Update Salary Data Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json({ message: "Updated successfully" })
  })
})

// Delete salary data
app.delete("/api/salary-data/:id", (req, res) => {
  const { id } = req.params
  const query = "DELETE FROM salary_data WHERE id = ?"
  db.query(query, [id], (err) => {
    if (err) {
      console.error("❌ Delete Salary Data Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json({ message: "Deleted successfully" })
  })
})

// ✅ Salary Deductions (From salaryDeduction.js)
app.use("/api/salary-deduction", salaryDeductionRoutes)

// ✅ TDS Rates
app.get("/api/tds-rates", (req, res) => {
  const query = "SELECT * FROM tds_rates"
  db.query(query, (err, results) => {
    if (err) {
      console.error("❌ Fetch TDS Rates Error:", err)
      return res.status(500).json({ error: "Database Error" })
    }
    res.json(results)
  })
})







const PORT = process.env.PORT || 8080;

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
// Start Server
// app.listen(5173, () => {
//   console.log("🚀 Server running on http://localhost:5173");

// });
