const express = require("express");
const mysql = require("mysql");
const cors = require("cors");
const sharp = require("sharp");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Parse JSON request bodies
app.use(express.json({}));

// Create database connection pool
const db = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASS || "Root@12345",
  database: process.env.DB_NAME || "crm_db",
  port: parseInt(process.env.DB_PORT || "3306"),
  connectionLimit: 10
});

// Test database connection
function testConnection() {
  db.getConnection((err, connection) => {
    if (err) {
      console.error("Database connection failed:", err);
      process.exit(1);
    }
    console.log("Database connection successful!");
    connection.release();
  });
}

testConnection();

// Helper functions remain the same...
async function processImage(base64Image) {
  if (!base64Image) return null;
  try {
    const matches = base64Image.match(/^data:([A-Za-z-+/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) return base64Image;

    const imageBuffer = Buffer.from(matches[2], "base64");

    const processedImageBuffer = await sharp(imageBuffer)
      .resize(300, 300, { fit: "inside" })
      .jpeg({ quality: 70 })
      .toBuffer();

    return `data:${matches[1]};base64,${processedImageBuffer.toString("base64")}`;
  } catch (error) {
    console.error("Error processing image:", error);
    return null;
  }
}

function formatDateForBackend(dateString) {
  if (!dateString) return null;
  const date = new Date(dateString);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

async function processEmployeeData(employee) {
  const processedEmployee = { ...employee };

  Object.keys(processedEmployee).forEach((key) => {
    if (processedEmployee[key] === "") processedEmployee[key] = null;
  });

  const dateFields = [
    "dateOfBirth", "joiningDate", "offerLetterDate", "appointmentLetterDate",
    "promotionDate", "startDate", "endDate", "payDate", "workStartDate", "workEndDate"
  ];
  dateFields.forEach((field) => {
    processedEmployee[field] = formatDateForBackend(processedEmployee[field]);
  });

  const booleanFields = [
    "offerLetterSent", "appointmentLetterSent", "eligibleForPromotion",
    "hra", "conveyanceAllowance", "medicalAllowance",
    "epfEmployee", "epfEmployer", "otherExpenses", "professionalTax",
    "gratuityProvision", "eligibleForIncentive"
  ];
  booleanFields.forEach((field) => {
    if (processedEmployee[field] === "yes" || processedEmployee[field] === true) {
      processedEmployee[field] = 1;
    } else if (processedEmployee[field] === "no" || processedEmployee[field] === false) {
      processedEmployee[field] = 0;
    }
  });

  if (processedEmployee.picture) processedEmployee.picture = await processImage(processedEmployee.picture);
  if (processedEmployee.aadharCardImage) processedEmployee.aadharCardImage = await processImage(processedEmployee.aadharCardImage);
  if (processedEmployee.panCardImage) processedEmployee.panCardImage = await processImage(processedEmployee.panCardImage);

  return processedEmployee;
}

// Get all employees
app.get("/api/employees", (req, res) => {
  db.query("SELECT * FROM employees", (err, rows) => {
    if (err) {
      console.error("Error fetching employees:", err);
      return res.status(500).json({ error: "Database error" });
    }
    res.json(rows);
  });
});

// Get employee by ID
app.get("/api/employees/:id", (req, res) => {
  const { id } = req.params;
  db.query("SELECT * FROM employees WHERE id = ?", [id], (err, rows) => {
    if (err) {
      console.error("Error fetching employee:", err);
      return res.status(500).json({ error: err.message });
    }
    if (rows.length === 0) return res.status(404).json({ error: "Employee not found" });
    res.json({ success: true, data: rows[0] });
  });
});

// Add Employee
app.post("/api/employees", async (req, res) => {
  try {
    const employee = await processEmployeeData(req.body);
    if (!employee || Object.keys(employee).length === 0) {
      return res.status(400).json({ error: "No employee data provided" });
    }

    db.query("INSERT INTO employees SET ?", employee, (err, result) => {
      if (err) {
        console.error("Error inserting employee:", err);
        return res.status(500).json({ error: err.message });
      }

      db.query("SELECT * FROM employees WHERE id = ?", [result.insertId], (err, rows) => {
        if (err) {
          console.error("Error fetching new employee:", err);
          return res.status(201).json({
            message: "Employee created successfully",
            employeeId: result.insertId
          });
        }

        res.status(201).json({
          message: "Employee created successfully",
          employee: rows[0]
        });
      });
    });
  } catch (error) {
    console.error("Error processing employee data:", error);
    res.status(500).json({ error: error.message });
  }
});

// Edit an employee
app.put("/api/employees/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const employee = await processEmployeeData(req.body);

    db.query("UPDATE employees SET ? WHERE id = ?", [employee, id], (err, result) => {
      if (err) {
        console.error("Error updating employee:", err);
        return res.status(500).json({ error: err.message });
      }

      if (result.affectedRows === 0) return res.status(404).json({ error: "Employee not found" });

      db.query("SELECT * FROM employees WHERE id = ?", [id], (err, rows) => {
        if (err) {
          console.error("Error fetching updated employee:", err);
          return res.status(200).json({ message: "Employee updated successfully" });
        }

        res.status(200).json({
          message: "Employee updated successfully",
          employee: rows[0]
        });
      });
    });
  } catch (error) {
    console.error("Error processing employee data:", error);
    res.status(500).json({ error: error.message });
  }
});

// Delete an employee
app.delete("/api/employees/:id", (req, res) => {
  const { id } = req.params;

  db.query("DELETE FROM employees WHERE id = ?", [id], (err, result) => {
    if (err) {
      console.error("Error deleting employee:", err);
      return res.status(500).json({ error: err.message });
    }

    if (result.affectedRows === 0) return res.status(404).json({ error: "Employee not found" });

    res.status(200).json({ message: "Employee deleted successfully" });
  });
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

module.exports = app;
