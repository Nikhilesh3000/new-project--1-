import db from "../config/db.js"


export const getExpenditures = (req, res) => {
  db.query(
    `SELECT id, srNo, DATE_FORMAT(billDate, '%Y-%m-%d') as billDate, particulars, vendorId, expenses, 
     amount, gst, tds, net, supplyBillNo, purchaseNo, supportingDocument, supportingDocumentName 
     FROM expenditure ORDER BY id DESC`,
    (error, results) => {
      if (error) return res.status(500).json({ error: "Failed to fetch expenditures" });

      if (!results || results.length === 0) {
        db.query("SELECT * FROM vendor", (vendorError, vendors) => {
          if (vendorError) return res.status(500).json({ error: "Failed to fetch vendors" });
          const placeholders = vendors.map((vendor, i) => ({
            id: `vendor-${vendor.id}`,
            srNo: `00${i + 1}`,
            billDate: vendor.dateOfRegistration ? new Date(vendor.dateOfRegistration).toISOString().split("T")[0] : "",
            particulars: vendor.vendorName,
            vendorId: vendor.id,
            expenses: vendor.expensesHead || "",
            amount: "",
            gst: "",
            tds: "",
            net: "",
            supplyBillNo: `BILL-${vendor.id}`,
            purchaseNo: `PO-${vendor.id}`,
            supportingDocument: null,
            supportingDocumentName: null,
          }));
          return res.json(placeholders);
        });
      } else {
        db.query("SELECT * FROM vendor", (vendorError, vendors) => {
          if (vendorError) return res.json(results);

          const existingVendorIds = results.map((e) => e.vendorId);
          const missing = vendors.filter((v) => !existingVendorIds.includes(v.id));
          const placeholders = missing.map((vendor, i) => ({
            id: `vendor-${vendor.id}`,
            srNo: `00${results.length + i + 1}`,
            billDate: vendor.dateOfRegistration ? new Date(vendor.dateOfRegistration).toISOString().split("T")[0] : "",
            particulars: vendor.vendorName,
            vendorId: vendor.id,
            expenses: vendor.expensesHead || "",
            amount: "",
            gst: "",
            tds: "",
            net: "",
            supplyBillNo: `BILL-${vendor.id}`,
            purchaseNo: `PO-${vendor.id}`,
            supportingDocument: null,
            supportingDocumentName: null,
          }));

          res.json([...results, ...placeholders]);
        });
      }
    }
  );
};

export const createExpenditure = (req, res) => {
  const {
    srNo, billDate, particulars, vendorId, expenses, amount,
    gst, tds, net, supplyBillNo, purchaseNo, supportingDocument, supportingDocumentName,
  } = req.body;

  if (!srNo || !billDate || !particulars || !vendorId || !expenses || !amount || !supplyBillNo || !purchaseNo)
    return res.status(400).json({ error: "Missing required fields" });

  const query = `
    INSERT INTO expenditure 
    (srNo, billDate, particulars, vendorId, expenses, amount, gst, tds, net, supplyBillNo, purchaseNo, supportingDocument, supportingDocumentName)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

  db.query(query, [
    srNo, billDate, particulars, vendorId, expenses, amount,
    gst, tds, net, supplyBillNo, purchaseNo, supportingDocument, supportingDocumentName,
  ], (err, results) => {
    if (err) return res.status(500).json({ error: "Failed to insert expenditure" });
    res.status(201).json({ id: results.insertId, message: "Expenditure created successfully" });
  });
};

export const updateExpenditure = (req, res) => {
  const { id } = req.params;
  const {
    srNo, billDate, particulars, vendorId, expenses, amount,
    gst, tds, net, supplyBillNo, purchaseNo, supportingDocument, supportingDocumentName,
  } = req.body;

  const query = `
    UPDATE expenditure 
    SET srNo = ?, billDate = ?, particulars = ?, vendorId = ?, expenses = ?, 
        amount = ?, gst = ?, tds = ?, net = ?, supplyBillNo = ?, purchaseNo = ?,
        supportingDocument = ?, supportingDocumentName = ?
    WHERE id = ?`;

  db.query(query, [
    srNo, billDate, particulars, vendorId, expenses, amount,
    gst, tds, net, supplyBillNo, purchaseNo, supportingDocument, supportingDocumentName, id,
  ], (err, results) => {
    if (err) return res.status(500).json({ error: "Failed to update expenditure" });
    if (results.affectedRows === 0) return res.status(404).json({ error: "Expenditure not found" });
    res.json({ message: "Expenditure updated successfully" });
  });
};

export const calculateGSTandTDS = (req, res) => {
  const { vendorId, amount } = req.body;

  if (!vendorId || !amount) return res.status(400).json({ error: "Vendor ID and amount are required" });

  db.query("SELECT gstRate, tdsRate FROM vendor WHERE id = ?", [vendorId], (err, results) => {
    if (err) return res.status(500).json({ error: "Failed to calculate amounts" });
    if (results.length === 0) return res.status(404).json({ error: "Vendor not found" });

    const { gstRate, tdsRate } = results[0];
    const gst = (amount * gstRate) / 100;
    const tds = (amount * tdsRate) / 100;
    const net = amount + gst - tds;

    res.json({ amount, gst, tds, net });
  });
};