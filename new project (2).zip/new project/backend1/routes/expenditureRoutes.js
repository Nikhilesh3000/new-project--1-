import express from "express"
import {
  getExpenditures,
  createExpenditure,
  updateExpenditure,
  calculateGSTandTDS,
} from "../controllers/expenditureController.js"
import { uploadDocument } from "../controllers/uploadController.js"

const router = express.Router()

router.get("/expenditures", getExpenditures)
router.post("/", createExpenditure)
router.put("/:id", updateExpenditure)
router.post("/calculate", calculateGSTandTDS);

export default router
 