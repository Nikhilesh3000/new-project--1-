import express from 'express';
import {
  getVendors,
  addVendor,
  updateVendor,
  deleteVendor,
  getVendors2,
  getVendorById,
  getExpenseHeads,
  getAllVendorDetails,
} from '../controllers/vendorController.js';

const router = express.Router();

router.get('/', getVendors);
router.post('/', addVendor);
router.put('/:id', updateVendor);
router.delete('/:id', deleteVendor);


router.get("/", getVendors2);
router.get("/vendor/:id", getVendorById);
router.get("/expense-heads", getExpenseHeads);
router.get("/vendor-details", getAllVendorDetails);


export default router;
